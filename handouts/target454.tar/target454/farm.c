/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned addval_320(unsigned x)
{
    return x + 3347663029U;
}

unsigned addval_371(unsigned x)
{
    return x + 3251079496U;
}

void setval_211(unsigned *p)
{
    *p = 3284633928U;
}

unsigned addval_396(unsigned x)
{
    return x + 2496104776U;
}

unsigned addval_282(unsigned x)
{
    return x + 408613500U;
}

unsigned getval_113()
{
    return 2425444576U;
}

unsigned addval_257(unsigned x)
{
    return x + 2421699195U;
}

void setval_294(unsigned *p)
{
    *p = 801345624U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

unsigned getval_414()
{
    return 3281047177U;
}

void setval_477(unsigned *p)
{
    *p = 3281178249U;
}

unsigned getval_215()
{
    return 3353381192U;
}

void setval_197(unsigned *p)
{
    *p = 3526935177U;
}

void setval_112(unsigned *p)
{
    *p = 3232026249U;
}

unsigned addval_171(unsigned x)
{
    return x + 3375944072U;
}

unsigned getval_243()
{
    return 3767093324U;
}

unsigned getval_281()
{
    return 3372794497U;
}

unsigned getval_429()
{
    return 3469302911U;
}

unsigned getval_304()
{
    return 3676357257U;
}

unsigned getval_209()
{
    return 3269495112U;
}

unsigned addval_223(unsigned x)
{
    return x + 3224949129U;
}

unsigned getval_337()
{
    return 3375944072U;
}

void setval_359(unsigned *p)
{
    *p = 3230978441U;
}

unsigned addval_298(unsigned x)
{
    return x + 3526938253U;
}

unsigned getval_377()
{
    return 3517565801U;
}

unsigned addval_341(unsigned x)
{
    return x + 2445445566U;
}

unsigned getval_192()
{
    return 3523789465U;
}

unsigned addval_322(unsigned x)
{
    return x + 2430634312U;
}

unsigned getval_210()
{
    return 3531919769U;
}

unsigned addval_154(unsigned x)
{
    return x + 3678981769U;
}

unsigned addval_133(unsigned x)
{
    return x + 3676881545U;
}

unsigned getval_336()
{
    return 3224949129U;
}

unsigned getval_398()
{
    return 1372049801U;
}

void setval_248(unsigned *p)
{
    *p = 3380924041U;
}

void setval_403(unsigned *p)
{
    *p = 2462222737U;
}

unsigned getval_481()
{
    return 3286273352U;
}

unsigned getval_160()
{
    return 3281306249U;
}

unsigned getval_128()
{
    return 3286276424U;
}

unsigned addval_339(unsigned x)
{
    return x + 3221802505U;
}

unsigned getval_274()
{
    return 3353381192U;
}

unsigned addval_447(unsigned x)
{
    return x + 3286272072U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
